number1 = int(input('Please enter your first number'))
number2 = int(input('Please enter your second number'))
quotient = number1 // number2
remainder = number1 % number2
print('The quotient is:', quotient)
print('The remainder is:', remainder)


