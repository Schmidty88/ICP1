print('Welcome to program 1')

value1 = 200
value2 = 300
value3 = 400

print(value1, 'plus', value2, 'plus', value3, 'equals', value1+value2+value3)

print('This is my code for project 1 question 1')







