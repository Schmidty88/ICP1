first_name = input('What is your first name?')
last_name = input('What is your last name?')

print('Your name is', last_name[::-1]+' ', first_name[::-1])


